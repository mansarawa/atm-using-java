package com.company;
import java.util.Scanner;
import java.io.*;
public class atmusingjava {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int amount=0;
        int balance=0;
        int choice;
        String username="admin";
        String password="admin3723";
        String name;
        String pass;
        while (true){

            System.out.println("Welcome To Mansa's ATM");
            System.out.println("enter your choice");
            System.out.println("press 1 for withdrow amount");
            System.out.println("press 2 for add amount");
            System.out.println("press 3 for check balance");
            System.out.println("press 4 for exit");
            choice=sc.nextInt();
            if (choice==1){
                System.out.println("enter your name");
                name=sc.next();
                System.out.println("enter your pass");
                pass=sc.next();
                if (name.equals(username) && pass.equals(password))
                {
                    System.out.println("enter amount for withdeow");
                    amount=sc.nextInt();
                    if (amount>balance){
                        System.out.println("Sorry your balance is insufficient");
                        System.out.println("Thanky for using Mansa's ATM");
                    }
                    else {
                        balance=balance-amount;
                        System.out.println("your requested of"+amount+"is successful");
                        System.out.println("Thanky for using Mansa's ATM");
                    }
                }
                else {
                    System.out.println("Your id or pass will be invalid");
                    System.out.println("Thanky for using Mansa's ATM");
                }
            }
            else if(choice==2){
                System.out.println("enter your name");
                name=sc.next();
                System.out.println("enter your pass");
                pass=sc.next();
                if (name.equals(username) && pass.equals(password)) {
                    System.out.println("enter amount for add");
                    amount = sc.nextInt();
                    balance = balance + amount;
                    System.out.println("Thanky for using Mansa's ATM");
                }
                else {
                    System.out.println("Your id or pass will be invalid");
                    System.out.println("Thanky for using Mansa's ATM");
                }
            }
            else if(choice==3){
                System.out.println("enter your name");
                name=sc.next();
                System.out.println("enter your pass");
                pass=sc.next();
                if (name.equals(username) && pass.equals(password)) {
                    System.out.println("Your current balance is:");
                    System.out.println(balance);
                    System.out.println("Thanky for using Mansa's ATM");
                }
                else {
                    System.out.println("Your id or pass will be invalid");
                    System.out.println("Thanky for using Mansa's ATM");
                }
            }
            else if(choice==4){
                System.out.println("Thanky for using Mansa's ATM");
                break;
            }
            else {
                System.out.println("invalid input");
            }
        }
    }
}
